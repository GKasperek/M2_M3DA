#ifndef GLSUPPORT_H
#define GLSUPPORT_H

/*!
*
* @file
*
* @brief
* @author F. Aubert
*
*/

#include "GL/glew.h"

#endif // GLSUPPORT_H

