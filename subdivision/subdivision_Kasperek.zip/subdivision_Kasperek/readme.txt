Kasperek Gautier

Catmul-clark n'est pas fait 
